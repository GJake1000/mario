#include "game_manager.h"
#include "menuManager.h"
#include <iostream>
#include <conio.h>  
#include <windows.h> 
#include <string>
#include <fstream>
#include <queue>

//=========================new game starter=================================
void game_manager::newGameStarter()
{
	// reset positions
	currentRoom = 0;
	turn = 0;
	resetPoints();
	gameLives.resetLives(fileH.getInitialLives());
	if (!isSilent)
		gameLives.draw();
	gameScore.reset(fileH.getInitialScore());
	screen.resetRoom();

	// Spring & Obstacle setup
	springs.clear();
	springDefFromMap(currentRoom);
	resetSpringState();
	obsDefFromMap(currentRoom);

	loadRiddles("riddles.txt");
	resetDoorVars();
}

void game_manager::resetPoints() {
	std::pair<int, int> startPos1 = screen.getPlayerStartPos(1);
	std::pair<int, int> startPos2 = screen.getPlayerStartPos(2);
	points[0].setPosition(startPos1.first, startPos1.second);
	points[1].setPosition(startPos2.first, startPos2.second);
	points[0].resetInventory(screen);
	points[1].resetInventory(screen);
}

void game_manager::resetDoorVars() {
	playerAtDoor = -1;
	playerAtDoorX = -1;
	playerAtDoorY = -1;
	waitingRoom = -1;
}
//=========================game manager constructor=================================
game_manager::game_manager(bool silent) : isSilent(silent), points{
	// initial positions	
	Point(1 ,15, '&', STARDARD_PLAYER_1_KEYS, Color::green, 10),  // w - up, d - right, x - down, a - left, s - stay
	Point(1 ,17, '$', STARDARD_PLAYER_2_KEYS, Color::blue, 76)  // i - up, l - right, m - down, j - left, k - stay
	}, gameLives()
{
	fileH.loadGlobal("global.txt");
	fileH.loadRiddles();

	points[0].setKeys(fileH.getP1Keys());
	points[1].setKeys(fileH.getP2Keys());

	// set game manager for each point
	points[0].setGameManager(this);
	points[1].setGameManager(this);

	gameOver = false;
}

//=========================run game manager=================================

bool game_manager::printOutput(const char* output) const  {
	if (isSilent)
		return true;
	eraseOutput();

	int len = strlen(output);
	int spaces_to_center = (Screen::MAX_X - len) / 2;

	gotoxyLegendSafe(spaces_to_center, 23);

	for (int i = 0; i < len; i++) {
		std::cout << output[i];
		if (i % 2 == 0)
			Sleep(1);
	}
	return true;
}

void game_manager::eraseOutput() const {
	gotoxyLegendSafe(0, 23);
	std::cout << std::string(Screen::MAX_X, ' ');
	gameLives.draw();
	gameScore.draw(turn, gameLives.getLives());
	gotoxyLegendSafe(35, 23);
	std::cout << "LIVE | SCORE";
}

bool game_manager::handleKB() {
	char key = 0;
	if (input(key)) {
		if (key == ESC) {
			if (canPause()) {
				bool menu = menuManager::printPauseScreen();
				if (menu) return true;				// go back to menu
				if (!isSilent) {
					cls();
					screen.draw(currentRoom);
					drawObs();
					gameLives.draw();


					if (screen.isDark(currentRoom) && !hasTorch()) {
						screen.setDark();
					}
				}
			}
			else
				return true;
		}
		else if (!gameOver) {
			for (auto& p : points)
				p.handleKeyPressed(key, screen, currentRoom);
		}
			
	}
	return false;
}

void game_manager::textOpt() {
	if (textAppears == true) {
		output_time++;
		if (output_time > 150)
		{
			output_time = 0;
			eraseOutput();
		}
	}
}

void game_manager::movePlayer(Point& p) {
	int idx = (p.getPlayerChar() == points[0].getPlayerChar()) ? 0 : 1;

	if (playerAtDoor == idx) { // if player is at door, do not move
		if (waitingRoom == currentRoom) {
			char doorChar = screen.charAt(p.getX(), p.getY(), currentRoom);
			p.draw(doorChar); // redraw player on door char
		}
		return;
	}

	char curChar = screen.charAt(p, currentRoom);
	if (!isSilent) p.draw(curChar);           // erase previous position

	int nextX = p.getNextX();  // calculate next position
	int nextY = p.getNextY();

	char item = screen.charAt(nextX, nextY, currentRoom);
	if (item != ' ')
		handleSpacialItem(p, nextX, nextY, item); // handle item at next position

	bool canMove = !screen.isWall(nextX, nextY, currentRoom); // check for wall
	tryTriggerSpringRelease(idx, p, canMove);

	p.move(canMove);
	if (!isSilent) p.draw();

	applyLaunchMovementIfNeeded(p);
}

void game_manager::initilDefine() {
	if (!isSilent) {
		hideCursor();
		screen.draw(currentRoom);
		drawObs();
		eraseOutput();
		if (screen.isDark(currentRoom))
			screen.setDark();
	}
	if (screen.isLastRoom(currentRoom)) {
		gameOver = true;
		reportEvent("game ended. score: " + std::to_string(gameScore.calc(turn, gameLives.getLives())));
	}
}

bool game_manager::gameFlow(bool& dark) {
	onOffLight(dark);
	if (gameLives.getLives() <= 0) {
		reportEvent("lost all lives");
		return false; // game over go to menu
	}
	checkBombActivation();

	for (int i = 0; i < 2; ++i) {
		movePlayer(points[i]);
	}

	if (handleKB()) return false;
	if (gameScore.calc(turn, gameLives.getLives()) == 0) {
		reportEvent("game ended reached 0 score");
		return false; // game over go to menu
	}
	textOpt();

	turn++;	//counts turns in the game
	if (!isSilent) {
		gameScore.draw(turn, gameLives.getLives());
		updateSleep();
	}
	return true;
}

//=========================handle spacial item=================================
void game_manager::handleSpacialItem(Point& p, int x, int y, char item) {
	switch (item) {
	case TORCH:
		handleTorch(p, x, y);
		break;

	case SWITCH:
		handleSwitch(x, y);
		break;

	case OFF_SWITCH:
		turnOff(x, y, currentRoom);
		break;

	case RIDDLE:
		handleRiddle(p, x, y);
		break;

	case KEY:
		handleKey(p, x, y);
		break;

	case BOMB:
		handleBomb(p, x, y);
		break;

	case OBSTACLE:
		handleObstacle(p, x, y);
		break;

	case SPRING:
		handleSpring(p, x, y);
		break;

	case DOOR:		//door to 0 (probably does not exist)
	case '1':		//door to 1
	case '2':
	case '3':       //door ??? win maybe?
		handleDoor(p, x, y); //only if has key == true
		break;
	}
}

//=========================handle torch=================================
void game_manager::handleTorch(Point& p, int x, int y) {
	if (p.drawToInventory(screen, currentRoom, TORCH)) {
		reportEvent("picked up torch");
		screen.setChar(x, y, currentRoom, EMPTY_CELL); // remove torch from the room 
	}
}

bool game_manager::hasTorch() const {
	return (points[0].checkInventory(screen, currentRoom) == TORCH || points[1].checkInventory(screen, currentRoom) == TORCH);
}

void game_manager::onOffLight(bool& dark) {
	if (!screen.isDark(currentRoom)) {
		dark = false;
		return;
	}

	bool darkNow = !hasTorch(); // if niether has torch it will become dark
	if (darkNow != dark) {      // check about now if anyone has torch
		if (darkNow) {
			if (!isSilent) screen.setDark();
			printOutput("Room is too dark to see!");
		}
		else{
			if (!isSilent) {
				screen.draw(currentRoom);
				drawObs();
			}
		}
	}
	dark = darkNow;
}

//=========================handle switch=================================
void game_manager::handleSwitch(int x, int y) {
	reportEvent("switch turned on");
	screen.setChar(x, y, currentRoom, OFF_SWITCH);

	for (int row = 0; row <= Screen::MAX_Y; row++)
		for (int col = 0; col <= Screen::MAX_X; col++)
			if (screen.charAt(col, row, currentRoom) == DOOR_D)
				screen.setChar(col, row, currentRoom, EMPTY_CELL); // open the door by putting empty cells where it was
}

void game_manager::turnOff(int x, int y, int roomNum) {
	reportEvent("switch turned off");
	for (int row = 0; row < Screen::MAX_Y; row++) {
		for (int col = 0; col <= Screen::MAX_X; col++) {
			if (screen.getInitialChar(col, row, roomNum) == 'D')
				screen.setChar(col, row, roomNum, 'D');
		}
	}
	screen.setChar(x, y, roomNum, SWITCH);
	if (roomNum == 1 && !hasTorch())
		screen.setDark();
}

bool game_manager::doorCondSw(DoorInfo* door, size_t& i) {
	if (i + 3 >= door->conditions.size())
		return false;
	int swX = std::stoi(door->conditions[i + 1]);
	int swY = std::stoi(door->conditions[i + 2]);
	int stateNeeded = std::stoi(door->conditions[i + 3]);
	char swChar = screen.charAt(swX, swY, currentRoom);
	bool isOn = (swChar == OFF_SWITCH);
	bool conditionMet = false;
	if (stateNeeded == 1 && isOn)
		conditionMet = true;
	else if (stateNeeded == 0 && !isOn)
		conditionMet = true;
	if (!conditionMet) {
		if (stateNeeded == 1)
			textAppears = printOutput("Need to turn the switch ON to enter!");
		else
			textAppears = printOutput("Need to turn the switch OFF to enter!");
		return false;
	}
	i += 3; // advance index past the switch condition
	return true;
}

//=========================handle riddle=================================
void game_manager::handleRiddle(Point& p, int x, int y) {
	if (solveRiddle(p)) {
		screen.setChar(x, y, currentRoom, EMPTY_CELL); // remove riddle from the room
	}
}

bool game_manager::handleAnswer(char correct, char ans, Point& p) {
	std::string status = (ans == correct) ? "correct" : "wrong";
	reportEvent("riddle answerd: " + std::string(1, ans) + " result: " + status);
	if (ans == correct) {
		if (!isSilent) {
			std::cout << "\n\n\n\n\n\n          CORRECT!";
			Sleep(2000);
		}
		gameScore.add(fileH.getRidScore());
		return true;

	}
	else {
		bool isDead = removeLife();
		if (!isSilent) {
			std::cout << "\n\n\n\n\n\n          WRONG!";
			Sleep(2000);
		}
		if (isDead) return false;
		p.setDirection(Direction::STAY);
		return false;
	}
}

bool game_manager::solveRiddle(Point& p) {
	char correct = printRiddle(currentRoom); 
	char ans = 0;
	while (true) {
		if (input(ans)) {
			if ('4' < ans || '1' > ans) continue;  // not in boundries
			bool wasRight = handleAnswer(correct, ans, p);
			if (!isSilent) {
				cls();
				screen.draw(currentRoom);
				drawObs();
				gameLives.draw();

				if (screen.isDark(currentRoom) && !hasTorch())
					screen.setDark();
			}
			return wasRight;
		}
	}
}

void game_manager::loadRiddles(const char* fileName) {
	std::ifstream file(fileName);
	if (!file.is_open()) {
		std::cerr << "Failed to open riddles file: " << fileName << std::endl;
		return;
	}
	riddles.clear();
	Riddle riddle;
	std::string line;

	while (std::getline(file, riddle.question)) {
		for (int i = 0; i < 4; ++i) {
			std::getline(file, riddle.options[i]);
		}
		std::string correct;
		std::getline(file, correct);
		if (!correct.empty())
			riddle.correctOption = correct[0];
		riddles.push_back(riddle);
	}
	file.close();
}

char game_manager::printRiddle(int index) const {
	if (index < 0 || index >= fileH.getRidCnt())
		return '\0'; // invalid index
	if (!isSilent) {
		cls();
		std::cout << riddles[index];
	}
	return riddles[index].correctOption;
}

//=========================handle key=================================
void game_manager::handleKey(Point& p, int x, int y) {
	if (p.drawToInventory(screen, currentRoom, KEY)) {
		reportEvent("picked up key");
		screen.setChar(x, y, currentRoom, EMPTY_CELL); // remove key from the room
	}
}

//=========================handle bomb=================================
void game_manager::handleBomb(Point& p, int x, int y) {
	if (p.drawToInventory(screen, currentRoom, BOMB)) {
		reportEvent("picked up bomb");
		screen.setChar(x, y, currentRoom, EMPTY_CELL); // remove bomb from the room
	}
}

bool game_manager::playerHit(int bombX, int bombY, int radius) const  {
	if (bombRoom == currentRoom) {
		for (const auto& p : points) {
			int dx = p.getX() - bombX;
			int dy = p.getY() - bombY;
			int distanceSquared = dx * dx + dy * dy;
			if (distanceSquared <= radius * radius) // radius squared (3*3)
				return true;

		}
	}
	return false;
}

void game_manager::activateBomb(Screen& screen, int x, int y, int roomNum) {
	// explode bomb at (x,y) in roomNum
	reportEvent("bomb exploaded at " + std::to_string(roomNum));
	int radius = fileH.getBombRadius(); // radius of explosion
	for (int row = y - radius; row <= y + radius; row++) {
		for (int col = x - radius; col <= x + radius; col++) {
			int distX = col - x;
			int distY = row - y;
			int distanceSquared = distX * distX + distY * distY;
			bool isOuterWall = (col == 0 || col == Screen::MAX_X || row == 0 || row == Screen::MAX_Y - 3);
			if (!isOuterWall && distanceSquared <= radius * radius) { // do not destroy outer walls
				screen.setChar(col, row, roomNum, EMPTY_CELL);
			}
		}
	}
	if (playerHit(x, y, radius)) {
		reportEvent("player hit by bomb");
		removeLife();
	}
}

void game_manager::setBombTimer(int x, int y, int roomNum) {
	reportEvent("bomb set at: " + std::to_string(roomNum) + " x: " + 
		std::to_string(x) + " y: " + std::to_string(y));
	bombDisposalTime = turn;
	bombX = x;
	bombY = y;
	bombRoom = roomNum;
}

void game_manager::checkBombActivation() {
	if (bombDisposalTime != -1 && turn - bombDisposalTime >= fileH.getBombTimer()) {
		activateBomb(screen, bombX, bombY, bombRoom);
		bombDisposalTime = -1; // reset bomb timer
	}
}

//===========================lose life=================================
bool game_manager::removeLife() {
	reportEvent("lost life");
	if (!gameLives.loseLife()) {
		if (!isSilent) {
			cls();
			gotoxyLegendSafe(30, 10);
			std::cout << "GAME OVER!";
			Sleep(2000);
		}
		return true;
	}
	return false;
}

//===========================handle obstacle=================================
void game_manager::handleObstacle(Point& p, int x, int y) {
	Obstacle* obs = findObs(x, y);

	Point& secPyr = (p.getPlayerChar() == points[0].getPlayerChar()) ? points[1] : points[0];
	//bool secPush = obs->loc(secPyr.getNextX(), secPyr.getNextY(), currentRoom);
	bool sameDir = (p.getDifX() == secPyr.getDifX() && p.getDifY() == secPyr.getDifY());

	//if (secPush && sameDir) { // both players are pushing the obstacle in the same direction
	//	obs->tryMove(p.getDifX(), p.getDifY(), screen);
	//}
}

Obstacle* game_manager::findObs(int x, int y) {
	for (auto& obs : obstacles)
		if (obs.getRoom() == currentRoom && obs.contains(Coord(x, y)))
			return &obs;
	return nullptr;
}

void game_manager::obsDefFromMap(int roomNum)
{
	obstacles.clear();

	std::vector<std::vector<bool>> vis(Screen::MAX_Y + 1, std::vector<bool>(Screen::MAX_X + 1, false));


	for (int y = 0; y <= Screen::MAX_Y; y++) {
		for (int x = 0; x <= Screen::MAX_X; x++) {

			if ((vis[y][x]) || (screen.getInitialChar(x, y, roomNum) != OBSTACLE))	//if we already cheched or if it's not an obstacle	
				continue;

			std::vector<Coord> cells;
			std::queue<Coord> q;	//queue for BFS	

			q.push(Coord(x, y));
			vis[y][x] = true;	//mark as visited

			while (!q.empty()) {
				Coord cur = q.front();
				q.pop();
				cells.push_back(cur);

				static const int dirX[4] = { 1, -1, 0, 0 };
				static const int dirY[4] = { 0, 0, 1, -1 };

				for (int k = 0; k < 4; k++) {
					int nx = cur.x + dirX[k];
					int ny = cur.y + dirY[k];

					if (!(nx >= 0 && nx <= Screen::MAX_X && ny >= 0 && ny <= Screen::MAX_Y) || (vis[ny][nx]) || (screen.getInitialChar(nx, ny, roomNum) != OBSTACLE))
						continue;//if out of bounds OR already visited OR not an obstacle cell, go to next

					vis[ny][nx] = true;	//mark as visited
					q.push(Coord(nx, ny));	//push to queue	
				}
			}
			obstacles.emplace_back(std::move(cells), Color::brown, roomNum); //create obstacle from the collected cells	
		}
	}
}

void game_manager::drawObs() {
	for (const auto& obs : obstacles)
		if (obs.getRoom() == currentRoom)
			obs.draw(screen);
}


//===========================handle spring=================================
void game_manager::handleSpring(Point& p, int x, int y)
{
	Spring* spr = findSpring(x, y);
	if (!spr)
		return;

	int idx;	//player 1 or player 2

	if (p.getPlayerChar() == points[0].getPlayerChar())
		idx = 0;
	else
		idx = 1;

	// If player is already being launched, spring tiles behave like normal obstacles/tiles.
	// (Spec: other rules still apply, but you don't "re-compress" while launched.)
	if (p.isSpringActive())
		return;

	// If this is the first spring tile for this compression, initialize compression direction toward wall
	if (charging[idx] == false) {
		int twDx = 0, twDy = 0;	//toward wall direction
		if (!spr->getTowardWallDir(screen, currentRoom, twDx, twDy))
			return;

		charging[idx] = true;
		chargeDirX[idx] = twDx;
		chargeDirY[idx] = twDy;
		chargingCount[idx] = 0;
		restoreHidden(idx); // restore any previously hidden cells for this player
	}

	// Only compress when moving toward the wall
	if (p.getDifX() == chargeDirX[idx] && p.getDifY() == chargeDirY[idx]) {
		chargingCount[idx]++;
		hideCell(idx, x, y); // visually collapse this spring char
	}
	// If the player tries to go sideways/back while still on spring tiles,
	// we do NOT release here; release is triggered centrally by tryTriggerSpringRelease().
}

Spring* game_manager::findSpring(int x, int y)
{
	for (auto& spr : springs)
		if (spr.contains(x, y, currentRoom))
			return &spr;
	return nullptr; // if not found 
}

void game_manager::springDefFromMap(int roomNum)
{
	springs.clear();

	for (int y = 0; y <= Screen::MAX_Y; y++) {
		for (int x = 0; x <= Screen::MAX_X; x++) {
			//we care only about coordinates that have a spring in them
			if (screen.getInitialChar(x, y, roomNum) != SPRING)		
				continue;
			
			//finds if spring has a connection to another springs
            bool left  = (x > 0 && screen.getInitialChar(x - 1, y, roomNum) == SPRING);
            bool right = (x < Screen::MAX_X && screen.getInitialChar(x + 1, y, roomNum) == SPRING);
            bool up    = (y > 0 && screen.getInitialChar(x, y - 1, roomNum) == SPRING);
            bool down  = (y < Screen::MAX_Y && screen.getInitialChar(x, y + 1, roomNum) == SPRING);
			int len;

			//pushes to the spring vector all adjacent springs
			if (!left && right) {
				len = 1;
				while (x + len <= Screen::MAX_X && screen.getInitialChar(x + len, y, roomNum) == SPRING)
					len++;
				springs.push_back(Spring(x, y, len, roomNum, false));
			}
			else if (!up && down) {
				len = 1;
				while (y + len <= Screen::MAX_Y && screen.getInitialChar(x, y + len, roomNum) == SPRING)
					len++;
				springs.push_back(Spring(x, y, len, roomNum, true));
			}
			else if (!left && !right && !up && !down) {
				len = 1;
				springs.push_back(Spring(x, y, len, roomNum, false));
				//what if i add here also vertical spring of len 1?
				//how do i do that :(
			}
		}
	}
}

void game_manager::hideCell(int idx, int x, int y)
{
	for (const auto& pr : hiddenCells[idx])
		if (pr.first == x && pr.second == y) 
			return;

	hiddenCells[idx].push_back({ x, y });
	screen.setChar(x, y, currentRoom, EMPTY_CELL); // hide it visually
}

void game_manager::restoreHidden(int idx)
{
	for (const auto& pr : hiddenCells[idx]) {
        screen.setChar(pr.first, pr.second, currentRoom, SPRING);
    }
    hiddenCells[idx].clear();
}

void game_manager::applyLaunchMovementIfNeeded(Point& p)
{
	if (!p.isSpringActive())
		return;

	int dx = p.getSpringDx();
	int dy = p.getSpringDy();
	int speed = p.getSpringSpeed();

	Point* otherP;

	if (p.getPlayerChar() == points[0].getPlayerChar())
		otherP = &points[1];
	else
		otherP = &points[0];

	for (int i = 0; i < speed; i++) {
		int nx = p.getX() + dx;		//new x
		int ny = p.getY() + dy;		//new y
		if (screen.charAt(nx, ny, currentRoom) == OBSTACLE) {
			Obstacle* obs = findObs(nx, ny);
			if (!obs)
				break;

			int force = 1 + speed;  // launched player's contribution

			bool secPush = obs->contains(Coord(otherP->getX() + dx, otherP->getY() + dy));
			bool sameDir = (dx == otherP->getDifX() && dy == otherP->getDifY());

			if (secPush && sameDir)
				force += 1 + otherP->getSpringSpeed();

			if (force >= obs->getVolume()) {
				if (!obs->tryMove(dx, dy, screen))
					break;
			}
			else {
				break;
			}

			// after moving the obstacle, the cell should be empty; if not, stop
			if (screen.charAt(nx, ny, currentRoom) == OBSTACLE)
				break;
		}
		if (screen.isWall(nx, ny, currentRoom))
			break;

		// COLLISION: launched player hits the other player
		if (nx == otherP->getX() && ny == otherP->getY()) {
			// give other player the same launch direction and speed
			otherP->setDirection(Direction::STAY);      // ignore previous direction
			otherP->startSpringEffect(dx, dy, speed);   // starts speed for speed^2 cycles (your existing API)
			break; // do not move into the other player's cell
		}

		// BOUNCE: launched player hits another spring
		if (screen.getInitialChar(nx, ny, currentRoom) == SPRING) 
		{	
			Spring* nextSpr = findSpring(nx, ny); // spring we are about to hit
			Spring* curSpr = findSpring(p.getX(), p.getY()); // spring under current position (if any)

			// If still moving inside the same spring segment, do NOT bounce.
			if (nextSpr != nullptr && nextSpr == curSpr) {
				// continue normally (do nothing special)
			}
			else if (nextSpr != nullptr) {

				int compressCount = traverseSpringTowardWallEnd(*nextSpr, nx, ny, &p);
				int twDx = 0, twDy = 0;
				nextSpr->getTowardWallDir(screen, currentRoom, twDx, twDy);

				int launchDx = -twDx;
				int launchDy = -twDy;

				p.setDirection(Direction::STAY);
				p.startSpringEffect(launchDx, launchDy, compressCount);

				return;
			}
		}

		// ERASE CORRECTLY: redraw the underlying map char at current position
		char under = screen.charAt(p, currentRoom);
		if (!isSilent) p.draw(under);

		// move + draw player
		p.setPosition(nx, ny);
		if (!isSilent) p.draw();
	}
	p.tickSpringEffect();
}

void game_manager::tryTriggerSpringRelease(int idx, Point& p, bool canMove)
{
	if (!charging[idx])
		return;

	int dx = p.getDifX();
	int dy = p.getDifY();

	bool stay = (dx == 0 && dy == 0);

	// "attempts to change direction" (not the compression direction)
	bool changeDir = !stay && !(dx == chargeDirX[idx] && dy == chargeDirY[idx]);

	// "reaches the wall": moving toward wall but can't move
	bool hitWall = (dx == chargeDirX[idx] && dy == chargeDirY[idx] && !canMove);

	if (!(stay || changeDir || hitWall))
		return;

	int speed = chargingCount[idx];
	int launchDx = -chargeDirX[idx];
	int launchDy = -chargeDirY[idx];

	// Spring returns to original length within a single cycle
	restoreHidden(idx);

	// reset compression state
	charging[idx] = false;
	chargingCount[idx] = 0;
	chargeDirX[idx] = 0;
	chargeDirY[idx] = 0;

	if (speed <= 0)
		return;

	// prevent the normal move this cycle; movement will come from spring effect
	p.setDirection(Direction::STAY);

	// launch direction is opposite of compression direction
    p.startSpringEffect(launchDx, launchDy, speed);
}

void game_manager::resetSpringState()
{
	for (int i = 0; i < 2; i++) {
		restoreHidden(i);
		hiddenCells[i].clear();
		charging[i] = false;
		chargingCount[i] = 0;
		chargeDirX[i] = 0;
		chargeDirY[i] = 0;
	}
}

int game_manager::traverseSpringTowardWallEnd(const Spring& spr, int startX, int startY, Point* pToMove)
{
	int twDx = 0, twDy = 0;
	if (!spr.getTowardWallDir(screen, currentRoom, twDx, twDy))
		return 1;

	int count = 0;
	int cx = startX, cy = startY;

	while (true) {
		if (screen.getInitialChar(cx, cy, currentRoom) != SPRING)
			break;

		// Optional: move+draw player along the spring
		if (pToMove != nullptr) {
			char under = screen.charAt(*pToMove, currentRoom);
			pToMove->draw(under);
			pToMove->setPosition(cx, cy);
			pToMove->draw();
		}

		count++;

		int nx = cx + twDx;
		int ny = cy + twDy;

		// Stop when the spring hits the wall-end
		if (screen.isWall(nx, ny, currentRoom))
			break;

		// Or when spring tiles stop (safety)
		if (screen.getInitialChar(nx, ny, currentRoom) != SPRING)
			break;

		cx = nx;
		cy = ny;
	}

	return (count > 0) ? count : 1;
}


//===========================handle door=================================
void game_manager::handleDoor(Point& currentPlayer, int x, int y) {
	DoorInfo* door = const_cast<DoorInfo*>(screen.getDoor(currentRoom, x, y));
	if (!door) return;
	
	// both players pass through the same door
	int pyrIdx = (currentPlayer.getPlayerChar() == points[0].getPlayerChar()) ? 0 : 1;
	int otherIdx = (pyrIdx == 1) ? 0 : 1;

	if (playerAtDoor != -1){
		if (playerAtDoor == pyrIdx)
			return; // its the same player, do nothing
		if (!canUnlock(currentPlayer, door)) return;

		bool sameDoor = (x == playerAtDoorX && y == playerAtDoorY && currentRoom == waitingRoom);
		if (sameDoor) {
			resetDoorVars();
			resetThingsAfterDoor(door->leadsToRoom, door, true);
		}
		else {
			resetThingsAfterDoor(door->leadsToRoom, door, false);
		}
		return;
	}
	// both players standing at door but one of them didnt pass first time
	if (points[otherIdx].getX() == x && points[otherIdx].getY() == y) {
		if (canUnlock(currentPlayer, door)) {
			resetDoorVars();
			resetThingsAfterDoor(door->leadsToRoom, door, true);
			return;
		}
		return;
	}

	if(!canUnlock(currentPlayer, door))
		return;

	playerAtDoor = pyrIdx; // freeze this player at door
	playerAtDoorX = x;
	playerAtDoorY = y;
	waitingRoom = currentRoom;
}

bool game_manager::canUnlock(Point& p, DoorInfo* door) {
	bool needKey = false;
	bool needRiddle = false;
	char inv1 = points[0].checkInventory(screen, currentRoom);
	char inv2 = points[1].checkInventory(screen, currentRoom);
	if (!checkCond(needKey, needRiddle, p, inv1, inv2, door))
		return false;
	if (needKey) {
		removeKeyAfterUse(inv1, inv2, p);
		for (size_t i = 0; i < door->conditions.size(); ++i) {
			if (door->conditions[i] == "KEY") {
				door->conditions.erase(door->conditions.begin() + i);
				--i;
			}
		}
	}
	return true;
}

void game_manager::resetThingsAfterDoor(int doorNum, const DoorInfo* door, bool moveBoth) {
	currentRoom = doorNum; //update current room
	springs.clear();
	springDefFromMap(currentRoom);
	resetSpringState();


	if (moveBoth) {
		points[0].setPosition(door->xLead, door->yLead);
		points[1].setPosition(door->xLead, door->yLead - 2);
		playerAtDoor = -1;
		waitingRoom = -1;
		reportEvent("both players moved to room" + std::to_string(doorNum));
	}
	else {
		int movingPlyrIdx = (playerAtDoor == 1) ? 0 : 1;
		points[movingPlyrIdx].setPosition(door->xLead, door->yLead);
		reportEvent("single player moved to room" + std::to_string(doorNum));
	}
	if (!isSilent) {
		cls();
		screen.draw(currentRoom);
		drawObs();
		gameLives.draw();
	}
	if (screen.isLastRoom(currentRoom))
		gameOver = true;
}

bool game_manager::checkCond(bool& needKey, bool& needRiddle, Point& p, const char inv1, const char inv2, DoorInfo* door) {
	for (size_t i = 0; i < door->conditions.size(); ++i) {
		std::string cond = door->conditions[i];

		if (cond == "SWITCH") {
			if(!doorCondSw(door, i)) 
				return false;
		}
		else if (cond == "KEY") {
			if (inv1 != KEY && inv2 != KEY) {
				textAppears = printOutput("Need a key to enter!");
				return false;
			}
			needKey = true;
		}
		else if (cond == "RIDDLE") {
			if (screen.searchItem(currentRoom, RIDDLE))
				return false;
			door->conditions.erase(door->conditions.begin() + i); // remove riddle condition after solving
			--i;
		}
	}
	return true;
}

void game_manager::removeKeyAfterUse(char inv1, char inv2, Point& currentPlayer) {
	if (currentPlayer.checkInventory(screen, currentRoom) == KEY) {
		currentPlayer.drawToInventory(screen, currentRoom, EMPTY_CELL);
	}
	else{
		Point& otherPlayer = (currentPlayer.getPlayerChar() == points[0].getPlayerChar()) ? points[1] : points[0];
		otherPlayer.drawToInventory(screen, currentRoom, EMPTY_CELL);
	}
}