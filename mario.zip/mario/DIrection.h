#pragma once


enum class Direction {
	UP,
	RIGHT,
	DOWN,
	LEFT,
	STAY,
	DISPOSE
};